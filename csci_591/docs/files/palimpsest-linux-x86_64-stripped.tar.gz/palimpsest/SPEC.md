# Palimpsest behavior

Palimpsest is a document workspace exposed through MCP tools over stdio. This
project pins MCP protocol version `2025-11-25`. Each message is one JSON-RPC
object on one line. A client initializes the server before calling tools.

The server returns tool results as MCP content and as `structuredContent` so a
program can inspect them without parsing prose. Tool errors have `isError: true`.
All identifiers are opaque strings returned by Palimpsest.

## Tools

| Tool | Arguments | Result |
| --- | --- | --- |
| `workspace_create` | `key` | `workspaceId` |
| `document_create` | `workspaceId`, `key`, `name`, `content` | `documentId`, `size` |
| `document_read` | `workspaceId`, `key`, `documentId` | `name`, `content`, `size` |
| `document_export` | `workspaceId`, `key`, `documentId` | `recordHex`, `size` |
| `document_delete` | `workspaceId`, `key`, `documentId` | `deleted` |
| `snapshot_create` | `workspaceId`, `key`, `documentId` | `snapshotId`, `size` |
| `snapshot_read` | `workspaceId`, `key`, `snapshotId` | `content`, `size` |
| `snapshot_delete` | `workspaceId`, `key`, `snapshotId` | `deleted` |

The nonempty bearer key supplied to `workspace_create` grants access only to
that workspace. Calls using another key must fail without changing state or
returning workspace content. Document and snapshot IDs are scoped to a
workspace. Clients must treat all returned IDs as opaque.

Document names are nonempty UTF-8 strings. Document content may contain up to
1,048,576 UTF-8 bytes. `size` always counts bytes.

`document_export` returns a packed record encoded as lowercase hexadecimal.
The first four decoded bytes are the content's UTF-8 byte length in
little-endian order. The remaining bytes are the content exactly as stored.
Its `size` is the number of decoded record bytes, including the four-byte
header. Every accepted document can be exported.

A snapshot captures the source document's bytes at creation. It must retain
those bytes even if the source document is later deleted. Snapshots are scoped
to their workspace: no document or snapshot content from another workspace may
be returned, regardless of similarities between contents.

A failed call must leave all workspaces unchanged.
