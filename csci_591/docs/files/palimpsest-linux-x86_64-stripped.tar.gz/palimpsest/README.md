# Palimpsest

Palimpsest is a binary-only MCP server for the CSCI 591 fuzzing assignment. It
manages keyed document workspaces and snapshots. Your
target is the `palimpsest` executable in this package. The expected behavior
of each tool is in [SPEC.md](SPEC.md).

## Choose a target

Use the package matching your system:

- On Apple Silicon macOS, use the `darwin-arm64` package and run
  `./palimpsest` directly. Keep `libclang_rt.asan_osx_dynamic.dylib` in the
  same directory as the executable.
- On Linux x86-64, run `./palimpsest` directly if its runtime libraries are
  available. Otherwise, use the supplied container definition.
- On another host, use the Linux x86-64 package in a container whose engine
  supports `linux/amd64` images.

Your report must identify the package, operating system, architecture, and
SHA-256 digest you tested. A finding only needs to reproduce on that identified
target; allocator behavior and exact triggering inputs can vary by platform.

## Running the server

Start `./palimpsest` as a subprocess. It reads one JSON-RPC message per line
from standard input and writes one response per line to standard output.
Diagnostics go to standard error. Use MCP protocol version `2025-11-25`.

For the Linux package, build and run the supplied container with Docker or
Podman when direct execution is unavailable:

```sh
docker build --platform linux/amd64 -f Containerfile -t palimpsest .
docker run --rm -i --platform linux/amd64 palimpsest
```

Substitute `podman` for `docker` if that is your container engine. Send the
same newline-delimited requests to the container's standard input.

On macOS, Gatekeeper may quarantine an executable downloaded from the course
site. After verifying the archive's SHA-256 digest, you can remove quarantine
from the extracted course directory if macOS refuses to launch it:

```sh
xattr -dr com.apple.quarantine palimpsest
```

Here `palimpsest` is the extracted directory containing both the executable
and its sanitizer runtime.

Begin each process with an `initialize` request and an
`notifications/initialized` notification:

```json
{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-11-25","capabilities":{},"clientInfo":{"name":"student-fuzzer","version":"1.0"}}}
{"jsonrpc":"2.0","method":"notifications/initialized"}
{"jsonrpc":"2.0","id":2,"method":"tools/list","params":{}}
```

The notification has no response. Send further calls as `tools/call` requests:

```json
{"jsonrpc":"2.0","id":3,"method":"tools/call","params":{"name":"workspace_create","arguments":{"key":"example-workspace-secret"}}}
```

Read identifiers from `result.structuredContent` and use them in later calls.
Pass the workspace key as `key` in subsequent tool arguments. Do not assume
that identifiers have a particular format. Tool failures set
`result.isError` to `true`; malformed MCP requests may instead receive a
JSON-RPC `error`.

## Fuzzing

Generate *sequences of valid tool calls* from a grammar. Keep track of the
workspaces, documents, and snapshots returned by the server so later grammar
productions can refer to them. Track the key for each workspace. Include
boundary lengths, ASCII and multibyte text, repeated content, multiple
workspaces, and occasional invalid or stale identifiers. A test case may use a
fresh server process or a fresh workspace within a persistent process.

Investigate crashes, sanitizer reports, and responses that violate the
behavior in `SPEC.md`. Save the exact message sequence and random seed for
each finding, then minimize the sequence while preserving the failure.

If you use the Linux container, you may build your fuzzer into a derived image
and have it launch `/usr/local/bin/palimpsest` as an ordinary subprocess. This
is much faster than starting a new container for every generated test case.
